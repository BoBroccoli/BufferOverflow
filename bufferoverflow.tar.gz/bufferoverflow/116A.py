print "A"*100
